import { Component, OnInit } from '@angular/core';
import { BrowserModule } from "@angular/platform-browser";
import { Movie } from "../model/movie";


@Component({
    selector: 'my-movie-list',
    templateUrl: 'app/Movie/view/movie.list.component.html'
})

export class MovieComponent  {
              selectedMovie:Movie=new Movie(2,'India');
              movies=[
                        new Movie(1,'Australia'),
                        new Movie(2,'India'),
                        new Movie(3,'UK'),
                        new Movie(4,'USA')
                        

              ];

}