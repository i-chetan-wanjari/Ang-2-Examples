"use strict";
var Movie = (function () {
    function Movie(movieId, movieName) {
        this.movieId = movieId;
        this.movieName = movieName;
    }
    return Movie;
}());
exports.Movie = Movie;
//# sourceMappingURL=movie.js.map