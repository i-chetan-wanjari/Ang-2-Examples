export class Movie{

    constructor(public movieId:number,public movieName : string){}


}